module.exports = {
    JWT_Secret : "ThisJsonWebTokenSecretKey"
};