const admin = require("firebase-admin");
const serviceAccount = require("./firebase-credentials-test.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const firebase_db = admin.firestore();

module.exports = {
  admin,
  firebase_db,
};
